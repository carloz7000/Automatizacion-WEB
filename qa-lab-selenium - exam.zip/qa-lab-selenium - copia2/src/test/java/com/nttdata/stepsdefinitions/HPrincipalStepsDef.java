package com.nttdata.stepsdefinitions;

import com.nttdata.steps.CarritoSteps;
import com.nttdata.steps.CuentaSteps;
import com.nttdata.steps.InicioSesionSteps;
import com.nttdata.steps.PlatanitosSteps;
import com.nttdata.steps.ProductoSteps;
import com.nttdata.steps.OfertasSteps;


import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import io.cucumber.java.es.Y;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HPrincipalStepsDef {

    private WebDriver driver;
    private Scenario scenario;

    private CarritoSteps carritoSteps;
    private CuentaSteps cuentaSteps;
    private OfertasSteps ofertasSteps;
    private InicioSesionSteps inicioSesionSteps;
    private PlatanitosSteps platanitosSteps;
    private ProductoSteps productoSteps;

    // ? traemos la data de InicioSesionSteps
    private InicioSesionSteps inicioSesionSteps(WebDriver driver){
        return new InicioSesionSteps(driver);
    }
    // ? traemos la data de CuentaSteps
    private CuentaSteps cuentaSteps(WebDriver driver){
        return new CuentaSteps(driver);
    }
    // ? traemos la data de OfertasSteps
    private OfertasSteps ofertasSteps(WebDriver driver){
        return new OfertasSteps(driver);
    }
    // ? traemos la data de ProductoSteps
    private ProductoSteps productoSteps(WebDriver driver){
        return new ProductoSteps(driver);
    }
    // ? traemos la data de CarritoSteps
    private CarritoSteps carritoSteps(WebDriver driver){
        return new CarritoSteps(driver);
    }
    // * ===============================================================================================================
    @Before(order = 1)
    public void setUp(){
        //setUp
        System.setProperty("webdriver.http.factory", "jdk-http-client");
        System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");

        //crear el driver
        driver = new ChromeDriver();
        //max
        driver.manage().window().maximize();
    }

    @Before(order = 2)
    public void setScenario(Scenario scenario){
        this.scenario = scenario;
    }

    @After
    public void quitDriver(){
        driver.quit();
    }
    // * ===============================================================================================================
    // ? ===============================================================================================================
    // ? PAGINA PRINCIPAL

    @Dado("que estoy en la pagina principal")
    public void queEstoyEnLaPaginaPrincipal() {
        driver.get("https://platanitos.com/");
        screenShot();
    }

    @Cuando("hago clic en boton Cuenta")
    public void hagoClicEnBotonCuenta() {
        platanitosSteps =new PlatanitosSteps(driver);
        // ! espera implicita => codificado en steps---->>>>
        platanitosSteps.seleccionarBotonCuenta();
        screenShot();
    }
    // ? ===============================================================================================================
    // ? PAGINA DE INICIO DE SESION

    @Entonces("valido AUTENTIFICACION pageLogin que debería aparecer el título de login de {string}")
    public void validoAUTENTIFICACIONPageLoginQueDeberíaAparecerElTítuloDeLoginDe(String expectedTitle) {
        String title =  inicioSesionSteps(driver).getTitleIni();
        //prueba: validamos el título del producto
        Assertions.assertEquals(expectedTitle, title);
    }

    @Y("inicio sesión con las credenciales usuario: {string} y contraseña: {string}")
    public void inicioSesiónConLasCredencialesUsuarioYContraseña(String correo, String password) {
        InicioSesionSteps inicioSesionSteps = new InicioSesionSteps(driver);
        inicioSesionSteps.typeCorreo(correo);
        inicioSesionSteps.typePassword(password);
        inicioSesionSteps.typeBtnIniciarSesion();
        screenShot();
    }
    // ? ===============================================================================================================
    // ? PAGINA DE CUENTA

    @Y("valido AUTENTIFICACION pageCuenta que debería aparecer el título de {string}")
    public void validoAUTENTIFICACIONPageCuentaQueDeberíaAparecerElTítuloDe(String expectedTitle) {
        String title =  cuentaSteps(driver).getTitleCuen();
        //prueba: validamos el título del producto
        Assertions.assertEquals(expectedTitle, title);
    }

    @Y("hago clic en categoria Ofertas")
    public void hagoClicEnCategoriaOfertas() {
        cuentaSteps =new CuentaSteps(driver);
        // ! espera implicita => codificado en steps---->>>>
        cuentaSteps.seleccionarBotonOfertas();
        screenShot();

    }
    // ? ===============================================================================================================
    // ? PAGINA DE OFERTAS

    @Y("valido AUTENTIFICACION paginaOfertas que debería aparecer el título de {string}")
    public void validoAUTENTIFICACIONPaginaOfertasQueDeberíaAparecerElTítuloDe(String expectedTitle) {
        String title =  ofertasSteps(driver).getTitleOfe();
        //prueba: validamos el título del producto
        Assertions.assertEquals(expectedTitle, title);

    }

    @Y("hago clic en la imagen OfertasDeVerano")
    public void hagoClicEnLaImagenOfertasDeVerano() {

        ofertasSteps =new OfertasSteps(driver);
        // ! espera implicita => codificado en steps---->>>>

        ofertasSteps.seleccionarBotonImagenOfertasAccesorios();

        screenShot();
    }
    // ? ===============================================================================================================
    // ? PAGINA DE PRODUCTO

    @Y("valido AUTENTIFICACION paginaProductos que debería aparecer el título de {string}")
    public void validoautentificacionPaginaProductosQueDeberíaAparecerElTítuloDe(String expectedTitle) {
        // * validando titulo Ofertas accesorios
        String title =  productoSteps(driver).getTitleAcce();
        //prueba: validamos el título del producto
        Assertions.assertEquals(expectedTitle, title);
        // * click en selecionar producto sombrero
        productoSteps =new ProductoSteps(driver);
        // ! espera implicita => codificado en steps---->>>>

        productoSteps.seleccionarSombrero();

        screenShot();

    }

    @Y("hago clic en boton AgregarAlCarrito")
    public void hagoClicEnBotonAgregarAlCarrito() {

        productoSteps =new ProductoSteps(driver);
        // ! espera implicita => codificado en steps---->>>>

        productoSteps.seleccionarAgregarAlCarrito();

        screenShot();
    }

    @Y("hago clic en boton Carrito")
    public void hagoClicEnBotonCarrito() {
        productoSteps =new ProductoSteps(driver);
        // ! espera implicita => codificado en steps---->>>>

        productoSteps.seleccionarBotonCarrito();

        screenShot();

    }
    // ? ===============================================================================================================
    // ? PAGINA DE CARRITO

    @Y("valido AUTENTIFICACION paginaCarrito que debería aparecer el título de {string}")
    public void validoAUTENTIFICACIONPaginaCarritoQueDeberíaAparecerElTítuloDe(String expectedTitle) {
        String title =  carritoSteps(driver).getTitleCarri();
        //prueba: validamos el título del producto
        Assertions.assertEquals(expectedTitle, title);
    }

    @Y("valido AUTENTIFICACION que debería aparecer mi compra de {string}")
    public void validoAUTENTIFICACIONQueDeberíaAparecerMiCompraDe(String expectedTitle) {
        String title =  carritoSteps(driver).getTitleNomb();
        //prueba: validamos el título del producto
        Assertions.assertEquals(expectedTitle, title);
    }
    // ? ===============================================================================================================
    // * ===============================================================================================================

    public void screenShot(){
        byte[] evidencia = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        this.scenario.attach(evidencia, "image/png", "evidencias");
    }

}
