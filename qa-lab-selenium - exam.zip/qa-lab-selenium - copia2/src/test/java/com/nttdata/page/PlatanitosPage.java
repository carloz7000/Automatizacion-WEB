package com.nttdata.page;

import org.openqa.selenium.By;

public class PlatanitosPage {

    //Localizadores de elementos
    public static By botonCuenta = By.xpath("//p[contains(text(),'Cuenta')]");



}