package com.nttdata.page;

import org.openqa.selenium.By;

public class ProductoPage {

    //Localizadores de elementos
    public static By SeleccionProducto = By.xpath("(//*[@data-position='7']//self::a)[1]");

    public static By BotonAgregarAlCarrito = By.xpath("//button[@id='btn_add_cart_full']");
    public static By BotonCarrito = By.xpath("//p[contains(text(),'Carrito')]");


    //Localizadores de elementos de validacion
    public static By TituloOfertasAccesorios = By.xpath("//h1[contains(text(),'Mujeres > zapatos > sandalias')]");

}