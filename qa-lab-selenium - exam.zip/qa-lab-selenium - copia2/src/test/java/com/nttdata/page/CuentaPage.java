package com.nttdata.page;

import org.openqa.selenium.By;

public class CuentaPage {

    //Localizadores de elementos
    public static By categoriaOfertas = By.xpath("//header/div[2]/nav[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[7]/h2[1]/a[1]");

    //Localizadores de elementos de validacion
    public static By TituloCuenta = By.xpath("//h1[contains(text(),'Cuenta')]");



}