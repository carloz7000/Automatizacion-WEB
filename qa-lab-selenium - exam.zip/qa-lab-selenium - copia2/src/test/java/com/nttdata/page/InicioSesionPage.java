package com.nttdata.page;

import org.openqa.selenium.By;

public class InicioSesionPage {

    //Localizadores de elementos
    public static By correoLogin = By.xpath("//input[@id='email']");
    public static By contraseñaLogin = By.xpath("//input[@id='password']");
    public static By botonIniciarSesion = By.xpath("//button[@id='btn_submit']");

    //Localizadores de elementos de validacion
    public static By TituloIniciarSesion = By.xpath("//h1[contains(text(),'Iniciar sesión')]");



}