package com.nttdata.page;

import org.openqa.selenium.By;

public class CarritoPage {

    //Localizadores de elementos
    public static By NombreProducto = By.xpath("//p[contains(text(),'Subtotal (1 producto)')]");

    //Localizadores de elementos de validacion
    public static By TituloCarrito = By.xpath("//h1[contains(text(),'Carrito')]");

}