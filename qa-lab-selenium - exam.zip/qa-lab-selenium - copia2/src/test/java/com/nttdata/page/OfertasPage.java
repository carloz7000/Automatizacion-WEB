package com.nttdata.page;

import org.openqa.selenium.By;

public class OfertasPage {

    //Localizadores de elementos
    public static By BotonImgOfertasAccesorios = By.xpath("//*[@alt='Ofertas banner 0']//self::img");


    //Localizadores de elementos de validacion
    public static By TituloOfertas = By.xpath("//h1[contains(text(),'Ofertas')]");

}