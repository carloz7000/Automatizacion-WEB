package com.nttdata.steps;

import com.nttdata.page.InicioSesionPage;
import com.nttdata.page.OfertasPage;
import com.nttdata.page.ProductoPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ProductoSteps {
    private WebDriver driver;

    //constructor
    public ProductoSteps(WebDriver driver){

        this.driver = driver;
    }

    public void esperaElemento(By by){
        // ! espera implicita
        // ! espera que el elemento exista para recien proceder
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(444));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }

    public String getTitleAcce() {
        esperaElemento(ProductoPage.TituloOfertasAccesorios);
        return this.driver.findElement(ProductoPage.TituloOfertasAccesorios).getText();
    }

    public void seleccionarSombrero() {
        // ! espera implicita
        // ! espera que el elemento exista para recien proceder
        esperaElemento(ProductoPage.SeleccionProducto);

        WebElement SeleccionProducto = driver.findElement(ProductoPage.SeleccionProducto);

        SeleccionProducto.click();

        try{
            Thread.sleep(5000);
        }catch (Exception e){

        }
    }



    public void seleccionarAgregarAlCarrito() {
        // ! espera implicita
        // ! espera que el elemento exista para recien proceder
        esperaElemento(ProductoPage.BotonAgregarAlCarrito);

        WebElement BotonAgregarAlCarrito = driver.findElement(ProductoPage.BotonAgregarAlCarrito);

        BotonAgregarAlCarrito.click();

        try{
            Thread.sleep(5000);
        }catch (Exception e){

        }
    }

    public void seleccionarBotonCarrito() {
        // ! espera implicita
        // ! espera que el elemento exista para recien proceder
        esperaElemento(ProductoPage.BotonCarrito);

        WebElement BotonCarrito = driver.findElement(ProductoPage.BotonCarrito);

        BotonCarrito.click();

        try{
            Thread.sleep(5000);
        }catch (Exception e){

        }
    }
}
