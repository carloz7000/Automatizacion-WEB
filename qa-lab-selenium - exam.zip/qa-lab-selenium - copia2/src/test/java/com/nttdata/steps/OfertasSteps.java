package com.nttdata.steps;

import com.nttdata.page.CuentaPage;
import com.nttdata.page.InicioSesionPage;
import com.nttdata.page.OfertasPage;
import com.nttdata.page.PlatanitosPage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class OfertasSteps {
    private WebDriver driver;

    //constructor
    public OfertasSteps(WebDriver driver){

        this.driver = driver;
    }

    public void esperaElemento(By by){
        // ! espera implicita
        // ! espera que el elemento exista para recien proceder
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(444));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }


    public String getTitleOfe() {
        esperaElemento(OfertasPage.TituloOfertas);
        return this.driver.findElement(OfertasPage.TituloOfertas).getText();
    }

    public void seleccionarBotonImagenOfertasAccesorios() {
        // ! espera implicita
        // ! espera que el elemento exista para recien proceder
        esperaElemento(OfertasPage.BotonImgOfertasAccesorios);
        WebElement botonImgOfertasAccesorios = driver.findElement(OfertasPage.BotonImgOfertasAccesorios);
        botonImgOfertasAccesorios.click();

        try{
            Thread.sleep(5000);
        }catch (Exception e){

        }
    }
}
