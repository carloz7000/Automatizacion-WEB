package com.nttdata.steps;

import com.nttdata.page.CarritoPage;

import com.nttdata.page.ProductoPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.time.Duration;


public class CarritoSteps {
    private WebDriver driver;

    //constructor
    public CarritoSteps(WebDriver driver){

        this.driver = driver;
    }

    public void esperaElemento(By by){
        // ! espera implicita
        // ! espera que el elemento exista para recien proceder
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(444));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }


    public String getTitleCarri() {
        esperaElemento(CarritoPage.TituloCarrito);
        return this.driver.findElement(CarritoPage.TituloCarrito).getText();
    }

    public String getTitleNomb() {
        esperaElemento(CarritoPage.NombreProducto);
        return this.driver.findElement(CarritoPage.NombreProducto).getText();
    }
}
