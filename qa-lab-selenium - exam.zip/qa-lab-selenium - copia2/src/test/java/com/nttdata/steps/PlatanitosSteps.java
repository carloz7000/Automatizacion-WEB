package com.nttdata.steps;

import com.nttdata.page.PlatanitosPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class PlatanitosSteps {
    private WebDriver driver;

    //constructor
    public PlatanitosSteps(WebDriver driver){

        this.driver = driver;
    }

    public void esperaElemento(By by){
        // ! espera implicita
        // ! espera que el elemento exista para recien proceder
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(444));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }

    public void seleccionarBotonCuenta() {
        // ! espera implicita
        // ! espera que el elemento exista para recien proceder
        esperaElemento(PlatanitosPage.botonCuenta);

        WebElement botonCuenta = driver.findElement(PlatanitosPage.botonCuenta);
        botonCuenta.click();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }
    }
}
