package com.nttdata.steps;

import com.nttdata.page.InicioSesionPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class InicioSesionSteps {
    private WebDriver driver;

    //constructor
    public InicioSesionSteps(WebDriver driver){

        this.driver = driver;
    }

    public void esperaElemento(By by){
        // ! espera implicita
        // ! espera que el elemento exista para recien proceder
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(444));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }


    public String getTitleIni() {
        esperaElemento(InicioSesionPage.TituloIniciarSesion);
        return this.driver.findElement(InicioSesionPage.TituloIniciarSesion).getText();
    }

    public void typeCorreo(String correo) {
        WebElement userInputElement = driver.findElement(InicioSesionPage.correoLogin);
        userInputElement.sendKeys(correo);
    }

    public void typePassword(String password) {
        this.driver.findElement(InicioSesionPage.contraseñaLogin).sendKeys(password);
    }

    public void typeBtnIniciarSesion() {

        this.driver.findElement(InicioSesionPage.botonIniciarSesion).click();
    }
}
