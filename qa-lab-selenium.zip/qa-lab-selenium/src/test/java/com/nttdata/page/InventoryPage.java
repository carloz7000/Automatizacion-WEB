package com.nttdata.page;

import org.openqa.selenium.By;

public class InventoryPage {

    public static By cuentaTitle = By.xpath("//h1[contains(text(),'Cuenta')]");
    public static By itemsCards = By.cssSelector("div.inventory_item");
}
